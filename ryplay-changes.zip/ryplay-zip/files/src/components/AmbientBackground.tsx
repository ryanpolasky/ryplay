import { motion } from "framer-motion";
import type { PaletteColors } from "../types/lastfm";
import { artworkProxyUrl } from "../lib/artworkLoader";

interface Props {
  colors: PaletteColors;
  artworkUrl?: string | null;
}

export default function AmbientBackground({ colors, artworkUrl }: Props) {
  const proxyUrl = artworkProxyUrl(artworkUrl);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      {/* Base dark layer */}
      <div className="absolute inset-0 bg-[#060609]" />

      {/* Blurred album art — most authentic color source */}
      {proxyUrl && (
        <motion.img
          key={proxyUrl}
          src={proxyUrl}
          alt=""
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.3 }}
          transition={{ duration: 2, ease: "easeOut" }}
          className="absolute inset-0 w-full h-full object-cover blur-[80px] scale-125 saturate-150"
        />
      )}

      {/* Dark vignette overlay to keep text readable */}
      <div className="absolute inset-0 vignette-overlay" />

      {/* Dominant blob — top-left */}
      <motion.div
        className="absolute -top-[5%] -left-[5%] md:-top-[20%] md:-left-[15%] w-[80vw] h-[80vw] md:w-[65vw] md:h-[65vw] rounded-full blur-[100px]"
        animate={{
          backgroundColor: colors.dominant,
          opacity: proxyUrl ? 0.3 : 0.15,
        }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      />

      {/* Vibrant blob — bottom-right */}
      <motion.div
        className="absolute -bottom-[5%] -right-[5%] md:-bottom-[15%] md:-right-[10%] w-[70vw] h-[70vw] md:w-[55vw] md:h-[55vw] rounded-full blur-[100px]"
        animate={{
          backgroundColor: colors.vibrant,
          opacity: proxyUrl ? 0.25 : 0.1,
        }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      />

      {/* Muted blob — center */}
      <motion.div
        className="absolute top-[30%] left-[10%] md:top-[20%] md:left-[30%] w-[55vw] h-[55vw] md:w-[40vw] md:h-[40vw] rounded-full blur-[120px]"
        animate={{
          backgroundColor: colors.muted,
          opacity: proxyUrl ? 0.15 : 0.06,
        }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      />
    </div>
  );
}
